import UIKit

class CalculatorViewController: UIViewController {
    
    @IBOutlet weak var displayLabel: UILabel!
    
    var currentInput: String = "0"
    var previousNumber: Double = 0
    var currentOperation: String = ""
    var isTypingNumber = false
    let historyFileName = "history.txt"
    
    override func viewDidLoad() {
        super.viewDidLoad()
        displayLabel.text = "0"
    }
    
    
    @IBAction func numberPressed(_ sender: UIButton) {
        let number = "\(sender.tag)"
        if isTypingNumber {
            if currentInput.count < 10 {
                currentInput += number
            }
        } else {
            currentInput = number
            isTypingNumber = true
        }
        displayLabel.text = currentInput
    }

    @IBAction func operatorPressed(_ sender: UIButton) {
        guard let op = sender.titleLabel?.text else{ return }
        if let num = Double(currentInput) {
            if !currentOperation.isEmpty {
                let result = performCalculation(num)
                previousNumber = result
                displayLabel.text = formatResult(result)
            } else {
                previousNumber = num
            }
        }
        
        currentOperation = op
        currentInput = "0"
        isTypingNumber = false
    }


    
    func performCalculation(_ num: Double) -> Double {
        switch currentOperation {
            case "+": return previousNumber + num
            case "-": return previousNumber - num
            case "x": return previousNumber * num
            case "/":
                if num == 0 {
                    DispatchQueue.main.async {
                        self.displayLabel.text = "Cannot divide by zero"
                    }
                    return 0  
                }
                return previousNumber / num
            case "%": return previousNumber.truncatingRemainder(dividingBy: num)
            default: return num
        }
    }



   
    @IBAction func equalsPressed(_ sender: UIButton) {
        if let num = Double(currentInput) {
            let result = performCalculation(num)
            let resultString = formatResult(result)
            let historyEntry = "\(previousNumber) \(currentOperation) \(num) = \(resultString)"
            
            displayLabel.text = resultString
            currentInput = resultString
            isTypingNumber = false
            currentOperation = ""
            
            saveToHistory(historyEntry)
        }
    }

   
    @IBAction func clearPressed(_ sender: UIButton) {
        currentInput = "0"
        previousNumber = 0
        currentOperation = ""
        displayLabel.text = "0"
        isTypingNumber = false
    }

    
    @IBAction func deletePressed(_ sender: UIButton) {
        if currentInput.count > 1 {
            currentInput.removeLast()
        } else {
            currentInput = "0"
        }
        displayLabel.text = currentInput
    }
    
    
    @IBAction func percentagePressed(_ sender: UIButton) {
        if let num = Double(currentInput) {
            let result = num / 100
            displayLabel.text = formatResult(result)
            currentInput = formatResult(result)
            isTypingNumber = false
        }
    }
    
    
    @IBAction func decimalPressed(_ sender: UIButton) {
        if !currentInput.contains(".") {
            currentInput += "."
            displayLabel.text = currentInput
        }
    }

    
    func saveToHistory(_ entry: String) {
        let fileURL = getFileURL()
        do {
            let fileHandle = try FileHandle(forWritingTo: fileURL)
            fileHandle.seekToEndOfFile()
            if let data = (entry + "\n").data(using: .utf8) {
                fileHandle.write(data)
            }
            fileHandle.closeFile()
        } catch {
            do {
                try (entry + "\n").write(to: fileURL, atomically: true, encoding: .utf8)
            } catch {
                print("Error saving history: \(error)")
            }
        }
    }

   
    func getFileURL() -> URL {
        let fileManager = FileManager.default
        let directory = fileManager.urls(for: .documentDirectory, in: .userDomainMask).first!
        return directory.appendingPathComponent(historyFileName)
    }

    
    func formatResult(_ result: Double) -> String {
        return result.truncatingRemainder(dividingBy: 1) == 0 ? String(format: "%.0f", result) : String(format: "%.6f", result)
    }
    
    
    @IBAction func openHistory(_ sender: UIButton) {
        if let historyVC = storyboard?.instantiateViewController(withIdentifier: "HistoryViewController") as? HistoryViewController {
            historyVC.modalPresentationStyle = .fullScreen
            present(historyVC, animated: true, completion: nil)
        } else {
            print("Error: Could not load HistoryViewController")
        }
    }

}
