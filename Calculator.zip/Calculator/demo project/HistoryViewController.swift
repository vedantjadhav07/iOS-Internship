import UIKit

class HistoryViewController: UIViewController {

    @IBOutlet weak var historyTextView: UITextView!
    let historyFileName = "history.txt"
    
    override func viewDidLoad() {
        super.viewDidLoad()
        loadHistory()
    }
    
    func loadHistory() {
        let fileURL = getFileURL()
        
       
        let fileManager = FileManager.default
        if !fileManager.fileExists(atPath: fileURL.path) {
            do {
                try "".write(to: fileURL, atomically: true, encoding: .utf8)
                print("history.txt created successfully")
            } catch {
                print("Error creating history.txt: \(error)")
            }
        }
        
        
        do {
            let history = try String(contentsOf: fileURL, encoding: .utf8)
            historyTextView.text = history.isEmpty ? "No History Available" : history
        } catch {
            print("Error loading history: \(error)")
            historyTextView.text = "No History Available"
        }
    }

    
   
    @IBAction func clearHistory(_ sender: UIButton) {
        let fileURL = getFileURL()
        do {
            try "".write(to: fileURL, atomically: true, encoding: .utf8)
            historyTextView.text = "History Cleared"
        } catch {
            print("Error clearing history: \(error)")
        }
    }
    
    func getFileURL() -> URL {
        let fileManager = FileManager.default
        let directory = fileManager.urls(for: .documentDirectory, in: .userDomainMask).first!
        let fileURL = directory.appendingPathComponent(historyFileName)
        print("History file path: \(fileURL.path)")
        return fileURL
    }

    
    
    @IBAction func closeHistory(_ sender: UIButton) {
        dismiss(animated: true)
    }
}
